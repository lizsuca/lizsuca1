package montadoras;

public abstract class Montadora {
	protected String nome;
	protected String CNPJ;

	// CHEVROLET
	public void produzirOnix(String modelo, String cor, int potencia, int carroID) {
	}
	
	public void produzirPrisma(String modelo, String cor, int potencia, int carroID) {
	}
	
	public void produzirCruze(String modelo, String cor, int potencia, int carroID) {
	}
	
	public void produzirCamaro(String modelo, String cor, int potencia, int carroID) {
	}
	// FORD
	public void produzirFiesta(String modelo, String cor, int potencia, int carroID) {
	}
	
	public void produzirFocus(String modelo, String cor, int potencia, int carroID) {
	}
	
	public void produzirFusion(String modelo, String cor, int potencia, int carroID) {
	}
	// HONDA
	public void produzirCity(String modelo, String cor, int potencia, int carroID) {
	}
	
	public void produzirFit(String modelo, String cor, int potencia, int carroID) {
	}
	// TOYOTA
	public void produzirEtios(String modelo, String cor, int potencia, int carroID) {
	}
	
	public void produzirCorolla(String modelo, String cor, int potencia, int carroID) {
	}
	
	public void produzirPrius(String modelo, String cor, int potencia, int carroID) {
	}
}
