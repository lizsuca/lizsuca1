package montadoras;

import carro.Carro;
import carro.modelos.toyota.Corolla;
import carro.modelos.toyota.Etios;
import carro.modelos.toyota.Prius;
import carro.pecas.Pneu;
import carro.pecas.Porta;
import carro.pecas.Roda;

public class Toyota extends Montadora {
	
	public void produzirCorolla(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Corolla(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Corolla " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
	
	public void produzirEtios(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Etios(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Etios " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
	
	public void produzirPrius(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Prius(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Prius " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
	
}
