package montadoras;

import carro.Carro;
import carro.modelos.honda.City;
import carro.modelos.honda.Fit;
import carro.pecas.Pneu;
import carro.pecas.Porta;
import carro.pecas.Roda;

public class Honda extends Montadora {

	public void produzirCity(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new City(modelo,cor,potencia,carroID);
		System.out.println("Produzido um City " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
	
	public void produzirFit(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Fit(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Fit " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
}
