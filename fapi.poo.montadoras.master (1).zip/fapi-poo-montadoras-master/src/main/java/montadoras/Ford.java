package montadoras;

import carro.Carro;
import carro.modelos.ford.Fiesta;
import carro.pecas.Pneu;
import carro.pecas.Porta;
import carro.pecas.Roda;

public class Ford extends Montadora {

	public void produzirFiesta(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Fiesta(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Fiesta " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
	
	public void produzirFocus(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Fiesta(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Focus " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
	
	public void produzirFusion(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Fiesta(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Fusion " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
}
