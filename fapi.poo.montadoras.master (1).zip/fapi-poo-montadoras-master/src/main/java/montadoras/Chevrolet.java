package montadoras;

import carro.Carro;
import carro.modelos.chevrolet.Onix;
import carro.modelos.chevrolet.Prisma;
import carro.pecas.Pneu;
import carro.pecas.Porta;
import carro.pecas.Roda;

public class Chevrolet extends Montadora {
	
	public void Montadora(String nome,String CNPJ) {
		this.nome = "Chevrolet";
		this.CNPJ = "1586";
	}
	
	public void produzirOnix(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Onix(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Onix " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
	
	public void produzirPrisma(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Prisma(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Prisma " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
	
	public void produzirCruze(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Prisma(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Cruze " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
	
	public void produzirCamaro(String modelo,String cor,int potencia,int carroID) {
		Carro carro = new Prisma(modelo,cor,potencia,carroID);
		System.out.println("Produzido um Camaro " + carro.getModelo() + " " + carro.getCor() + " " + carro.getPotencia() + "cv." + " ID: "+ carroID);
		Pneu.criarPneus(carroID);
		Porta.criarPortas(carroID);
		Roda.criarRodas(carroID);
	}
	
}
