package carro.modelos.ford;

import carro.Carro;

public class Fiesta extends Carro {
	
	public Fiesta(String modelo, String cor,int potencia,int ID) {
		super();
		this.modelo = modelo;
		this.cor = cor;
		this.potencia = potencia;
		this.ID = ID;
	}
}
