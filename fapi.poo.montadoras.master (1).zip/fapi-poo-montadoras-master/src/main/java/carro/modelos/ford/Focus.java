package carro.modelos.ford;

import carro.Carro;

public class Focus extends Carro {
	
	public Focus(String modelo, String cor,int potencia,int ID) {
		super();
		this.modelo = modelo;
		this.cor = cor;
		this.potencia = potencia;
		this.ID = ID;
	}
}
