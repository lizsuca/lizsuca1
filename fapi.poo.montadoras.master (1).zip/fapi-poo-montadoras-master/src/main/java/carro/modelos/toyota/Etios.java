package carro.modelos.toyota;

import carro.Carro;

public class Etios extends Carro {
	
	public Etios(String modelo, String cor,int potencia,int ID) {
		super();
		this.modelo = modelo;
		this.cor = cor;
		this.potencia = potencia;
		this.ID = ID;
	}
}
