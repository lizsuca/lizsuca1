package carro.modelos.chevrolet;

import carro.Carro;

public class Cruze extends Carro {
	
	public Cruze(String modelo, String cor,int potencia,int ID) {
		super();
		this.modelo = modelo;
		this.cor = cor;
		this.potencia = potencia;
		this.ID = ID;
	}
}
