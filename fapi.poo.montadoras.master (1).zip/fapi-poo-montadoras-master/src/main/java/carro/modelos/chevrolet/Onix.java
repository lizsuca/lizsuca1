package carro.modelos.chevrolet;

import carro.Carro;

public class Onix extends Carro {
	
	public Onix(String modelo, String cor,int potencia,int ID) {
		super();
		this.modelo = modelo;
		this.cor = cor;
		this.potencia = potencia;
		this.ID = ID;
	}
}
