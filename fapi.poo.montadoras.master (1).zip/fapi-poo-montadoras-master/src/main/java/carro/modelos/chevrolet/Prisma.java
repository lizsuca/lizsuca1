package carro.modelos.chevrolet;

import carro.Carro;

public class Prisma extends Carro {
	
	public Prisma(String modelo, String cor,int potencia,int ID) {
		super();
		this.modelo = modelo;
		this.cor = cor;
		this.potencia = potencia;
		this.ID = ID;
	}
}
