package carro.pecas;

public class Porta extends Componentes{
	
	public Porta(int carroID) {
		super();
		this.carroID = carroID;
	}
	
	public static void criarPortas(int carroID) {
		Porta porta1 = new Porta(carroID);
		Porta porta2 = new Porta(carroID);
		Porta porta3 = new Porta(carroID);
		Porta porta4 = new Porta(carroID);
		//System.out.println("Portas pertencentes ao carro: " + carroID);
	}
}
