package carro.pecas;

public abstract class Componentes {
	protected int carroID;
}
