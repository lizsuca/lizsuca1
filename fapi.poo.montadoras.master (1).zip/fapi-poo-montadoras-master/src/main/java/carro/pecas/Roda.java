package carro.pecas;

public class Roda extends Componentes {
	
	public Roda(int carroID) {
		super();
		this.carroID = carroID;
	}
	
	public static void criarRodas(int carroID) {
		Roda roda1 = new Roda(carroID);
		Roda roda2 = new Roda(carroID);
		Roda roda3 = new Roda(carroID);
		Roda roda4 = new Roda(carroID);
		//System.out.println("Rodas pertencentes ao carro: " + carroID);
	}
}
