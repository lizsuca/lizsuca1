package carro.pecas;

public class Pneu extends Componentes {
	
	public Pneu(int carroID) {
		super();
		this.carroID = carroID;
	}
	
	public static void criarPneus(int carroID) {
		Pneu pneu1 = new Pneu(carroID);
		Pneu pneu2 = new Pneu(carroID);
		Pneu pneu3 = new Pneu(carroID);
		Pneu pneu4 = new Pneu(carroID);
		//System.out.println("Pneus pertencentes ao carro: " + carroID);
	}
}
