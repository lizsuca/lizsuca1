package carro;

public abstract class Carro {
	protected String modelo;
	protected String cor;
	protected int potencia;
	protected int ID;
	
	public String getModelo() {
		return modelo;
	}
	public String getCor() {
		return cor;
	}
	public int getPotencia() {
		return potencia;
	}
	
}
