package main;

public class Main {

	public static void main(String[] args) {
		
		System.out.println("Bem vindo(a) ao simulador de linhas de produção! :)\n");
		
		LinhaDeProducao.controleLinhaChevrolet();
		LinhaDeProducao.controleLinhaFord();
		LinhaDeProducao.controleLinhaHonda();
		LinhaDeProducao.controleLinhaToyota();
	}

}
