package main;

import montadoras.Chevrolet;
import montadoras.Ford;
import montadoras.Honda;
import montadoras.Montadora;
import montadoras.Toyota;

public class LinhaDeProducao {

	static int controleID = 1; // Essa é a variável de controle dos carros
		
	public static void controleLinhaChevrolet() {
		Montadora montadora = new Chevrolet();
		
		System.out.println("Linha de produção da CHEVROLET:\n");
		
		for(; controleID < 10; controleID++) 
			montadora.produzirOnix("Hatch", "Marrom", 106, controleID);
		System.out.println(" ");
		
		for(; controleID < 20; controleID++) 
			montadora.produzirPrisma("Sedan", "Cinza", 106, controleID);
		System.out.println(" ");
		
		for(; controleID < 30; controleID++) 
			montadora.produzirCruze("Sedan", "Preto", 153, controleID);
		System.out.println(" ");
		
		for(; controleID < 40; controleID++) 
			montadora.produzirCamaro("Coupé", "Amarelo", 461, controleID);
		System.out.println(" ");
		
	}
	
	public static void controleLinhaFord() {
		Montadora montadora = new Ford();
		
		System.out.println("Linha de produção da FORD:\n");
		
		for(; controleID < 50; controleID++) 
			montadora.produzirFiesta("Compacto", "Azul", 70, controleID);
		System.out.println(" ");
		
		for(; controleID < 60; controleID++) 
			montadora.produzirFocus("Sport", "Laranja", 100, controleID);
		System.out.println(" ");
		
		for(; controleID < 70; controleID++) 
			montadora.produzirFusion("Sedan", "Preto", 153, controleID);
		System.out.println(" ");
		
	}
	
	public static void controleLinhaHonda() {
		Montadora montadora = new Honda();
		
		System.out.println("Linha de produção da HONDA:\n");
		
		for(; controleID < 80; controleID++) 
			montadora.produzirCity("Sedan", "Cinza", 130, controleID);
		System.out.println(" ");
		
		for(; controleID < 90; controleID++) 
			montadora.produzirFit("Sedan", "Preto", 110, controleID);
		System.out.println(" ");
		
	}
	
	public static void controleLinhaToyota() {
		Montadora montadora = new Toyota();
		
		System.out.println("Linha de produção da TOYOTA:\n");
		
		for(; controleID < 100; controleID++) 
			montadora.produzirCorolla("Sedan", "Branco", 140, controleID);
		System.out.println(" ");
		
		for(; controleID < 110; controleID++) 
			montadora.produzirEtios("Sedan", "Preto", 90, controleID);
		System.out.println(" ");
		
		for(; controleID < 120; controleID++) 
			montadora.produzirPrius("Compacto", "Vermelho", 120, controleID);
		System.out.println(" ");
		
	}
}
