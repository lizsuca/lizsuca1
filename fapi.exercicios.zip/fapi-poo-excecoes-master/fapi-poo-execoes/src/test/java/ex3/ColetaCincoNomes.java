package ex3;

import ex1.NomeInvalidoException;

public class ColetaCincoNomes {
	private String nome;
	private int nomesValidos;
	private int nomesInvalidos;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) throws NomeInvalidoException{
		try {
			if(nome.startsWith("_")) {
				nomesInvalidos++;
				throw new NomeInvalidoException("Não é permitido começar um nome com '_' (underline). Motivo: '" + nome + "'.");
			}
			else {
				this.nome = nome;
				nomesValidos++;
			}
				
		}
		catch(NomeInvalidoException e) {
			System.out.println("NomeInvalidoException: " + e.getMessage());
		}
		finally{
			this.nome = nome;
		}
		
		
	}

	public int getNomesValidos() {
		return nomesValidos;
	}
	
	public int getNomesInvalidos() {
		return nomesInvalidos;
	}
	
}
