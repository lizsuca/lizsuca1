package main;

import java.util.Scanner;

import ex1.NomeInvalidoException;
import ex2.ColetaNome;
import ex3.ColetaCincoNomes;

public class Main {
	
	public static void ex2() throws NomeInvalidoException {
		Scanner scanner = new Scanner(System.in);
		ColetaNome coleta = new ColetaNome();
		
		System.out.println("Digite um nome: ");
	    coleta.setNome(scanner.nextLine());
	}
	
	public static void ex3() throws NomeInvalidoException {
		Scanner scanner = new Scanner(System.in);
		ColetaCincoNomes coleta = new ColetaCincoNomes();
		
		for(int i = 1; i < 6; i++) {
			System.out.println("Digite o "+ i +"º nome: ");
			coleta.setNome(scanner.nextLine());
		}
		
		System.out.println("Nomes válidos: " + coleta.getNomesValidos());
		System.out.println("Nomes que deram erro: " + coleta.getNomesInvalidos());
		
	}

	public static void main (String[] args) throws NomeInvalidoException {
		ex3();
	}


}
