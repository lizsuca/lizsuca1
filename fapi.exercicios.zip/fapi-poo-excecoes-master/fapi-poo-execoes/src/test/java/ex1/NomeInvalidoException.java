package ex1;

public class NomeInvalidoException extends Exception{

    private static final long serialVersionUID = 35L;
    private String nome;

    public NomeInvalidoException(String msg){
        super(msg);
    }

    public NomeInvalidoException(String msg, Throwable causa){
        super(msg, causa);
    }

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}