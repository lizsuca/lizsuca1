package ex5;

public class Triangulo{
	int a;
	int b;
	int c;
		
	public String determinaTriangulo() throws ArestasInvalidasException{
		try {
			if(((a == b) && (a != c)) || ((b == c) && (b != a)) || ((a == c) && (b != a))) 
				return "Isóceles";
			else if (( a * a == b * b + c * c ) || ( b * b == a * a + c * c ) || ( c * c == b * b + a * a ))
				return "Retângulo";
			else if ( (a != b) && (a != c) && (b != c) ) 
				return "Escaleno";
			else {
				throw new ArestasInvalidasException ("Valores informados não formam um triângulo.");
			}
		}
		catch(ArestasInvalidasException e) {
			System.out.println("NomeInvalidoException: " + e.getMessage());
		}
		finally {
			
		}
		return null;
	}
}