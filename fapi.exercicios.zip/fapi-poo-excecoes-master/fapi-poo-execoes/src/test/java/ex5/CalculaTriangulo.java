package ex5;

import java.util.Scanner;

public class CalculaTriangulo {
	public static void main(String[] args) throws ArestasInvalidasException {
		Scanner scanner = new Scanner (System.in);
		Triangulo triangulo = new Triangulo();
		
		System.out.print("Digite o valor da 1ª aresta: ");
		triangulo.a = scanner.nextInt();
		System.out.print("Digite o valor da 2ª aresta: ");
		triangulo.b = scanner.nextInt();
		System.out.print("Digite o valor da 3ª aresta: ");
		triangulo.c = scanner.nextInt();
		
		if(triangulo.determinaTriangulo() != null)
			System.out.println("Este é um Triângulo " + triangulo.determinaTriangulo());
	}
}
