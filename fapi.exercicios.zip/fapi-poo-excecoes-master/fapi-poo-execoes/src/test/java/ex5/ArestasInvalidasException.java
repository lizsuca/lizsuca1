package ex5;

public class ArestasInvalidasException extends Exception{

	private static final long serialVersionUID = 2005L;
	
	public ArestasInvalidasException(String msg){
        super(msg);
    }

    public ArestasInvalidasException(String msg, Throwable causa){
        super(msg, causa);
    }
}
