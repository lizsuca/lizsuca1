package ex4;

public class EX4 {
	public static void main(String[] args) {
		int vetorDeNumeros[] = new int[4];
		for (int i = 0; i < 4; i++) {
		vetorDeNumeros[i] = i;
		}
		System.out.println("O número é: " + vetorDeNumeros[0]);
		System.out.println("O número é: " + vetorDeNumeros[1]);
		System.out.println("O número é: " + vetorDeNumeros[2]);
		}
}
