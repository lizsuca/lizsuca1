package ex2;

import ex1.NomeInvalidoException;

public class ColetaNome {
	private String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) throws NomeInvalidoException{
		if(nome.startsWith("_"))
			throw new NomeInvalidoException("Não é permitido começar um nome com '_' (underline). Motivo: '" + nome + "'.");
		else
			this.nome = nome;
	}
	
	
}
